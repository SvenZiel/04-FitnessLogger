﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FitnessLogger.Data;
using FitnessLogger.Models;

namespace FitnessLogger.Controllers
{
    public class GewichtsController : Controller
    {
        private readonly Kontext _context;

        public GewichtsController(Kontext context)
        {
            _context = context;
        }

        // GET: Gewichts
        public async Task<IActionResult> Index(string sortOrder)
        {
            var kontext = _context.Gewichte.Include(g => g.Nutzer);

            // Sortierung vornehmen
            ViewBag.GewichtSortParm = sortOrder == "Gewicht" ? "gewicht_desc" : "Gewicht";
            ViewBag.DatumSortParm = sortOrder == "Datum" ? "datum_desc" : "Datum";

            var weight = from s in kontext select s;

            switch (sortOrder)
            {
                case "Gewicht":
                    weight = weight.OrderBy(s => s.Gewichte);
                    break;
                case "gewicht_desc":
                    weight = weight.OrderByDescending(s => s.Gewichte);
                    break;
                case "Datum":
                    weight = weight.OrderBy(s => s.Datum);
                    break;
                case "datum_desc":
                    weight = weight.OrderByDescending(s => s.Datum);
                    break;
                default:
                    weight = weight.OrderByDescending(s => s.Datum);
                    break;
            }

            return View(await weight.ToListAsync());
        }

        // GET: Gewichts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var gewicht = await _context.Gewichte
                .Include(g => g.Nutzer)
                .SingleOrDefaultAsync(m => m.GewichtID == id);
            if (gewicht == null)
            {
                return NotFound();
            }

            return View(gewicht);
        }

        // GET: Gewichts/Create
        public IActionResult Create()
        {
            ViewData["NutzerID"] = new SelectList(_context.Nutzer, "NutzerID", "Benutzername");
            return View();
        }

        // POST: Gewichts/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("GewichtID,Datum,Gewichte,NutzerID")] Gewicht gewicht)
        {
            if (ModelState.IsValid)
            {
                _context.Add(gewicht);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["NutzerID"] = new SelectList(_context.Nutzer, "NutzerID", "Benutzername", gewicht.NutzerID);
            return View(gewicht);
        }

        // GET: Gewichts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var gewicht = await _context.Gewichte.SingleOrDefaultAsync(m => m.GewichtID == id);
            if (gewicht == null)
            {
                return NotFound();
            }
            ViewData["NutzerID"] = new SelectList(_context.Nutzer, "NutzerID", "Benutzername", gewicht.NutzerID);
            return View(gewicht);
        }

        // POST: Gewichts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("GewichtID,Datum,Gewichte,NutzerID")] Gewicht gewicht)
        {
            if (id != gewicht.GewichtID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(gewicht);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GewichtExists(gewicht.GewichtID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["NutzerID"] = new SelectList(_context.Nutzer, "NutzerID", "Benutzername", gewicht.NutzerID);
            return View(gewicht);
        }

        // GET: Gewichts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var gewicht = await _context.Gewichte
                .Include(g => g.Nutzer)
                .SingleOrDefaultAsync(m => m.GewichtID == id);
            if (gewicht == null)
            {
                return NotFound();
            }

            return View(gewicht);
        }

        // POST: Gewichts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var gewicht = await _context.Gewichte.SingleOrDefaultAsync(m => m.GewichtID == id);
            _context.Gewichte.Remove(gewicht);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GewichtExists(int id)
        {
            return _context.Gewichte.Any(e => e.GewichtID == id);
        }
    }
}
