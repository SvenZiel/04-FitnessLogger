﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FitnessLogger.Data;
using FitnessLogger.Models;

namespace FitnessLogger.Controllers
{
    public class UebungsController : Controller
    {
        private readonly Kontext _context;

        public UebungsController(Kontext context)
        {
            _context = context;
        }

        // GET: Uebungs
        public async Task<IActionResult> Index(string sortOrder, string searchString)
        {
            var kontext = _context.Uebungen.Include(u => u.Muskelgruppe);

             // Sortierung vornehmen
            ViewBag.MuskelgruppeSortParm = String.IsNullOrEmpty(sortOrder) ? "muskelgruppe_desc" : "";
            ViewBag.BezeichnungSortParm = sortOrder == "Bezeichnung" ? "bezeichnung_desc" : "Bezeichnung";

            var searchUebungen = from s in kontext select s;

            if (!String.IsNullOrEmpty(searchString))
            {
                searchUebungen = searchUebungen.Where(s => s.Muskelgruppe.Bezeichnung.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "bezeichnung_desc":
                    searchUebungen = searchUebungen.OrderByDescending(s => s.Bezeichnung);
                    break;
                case "muskelgruppe_desc":
                    searchUebungen = searchUebungen.OrderByDescending(s => s.Muskelgruppe.Bezeichnung);
                    break;
                case "Bezeichnung":
                    searchUebungen = searchUebungen.OrderBy(s => s.Bezeichnung);
                    break;
                default:
                    searchUebungen = searchUebungen.OrderBy(s => s.Muskelgruppe.Bezeichnung);
                    break;
            }

            return View(await searchUebungen.ToListAsync());
        }

        // GET: Uebungs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uebung = await _context.Uebungen
                .Include(u => u.Muskelgruppe)
                .SingleOrDefaultAsync(m => m.UebungID == id);
            if (uebung == null)
            {
                return NotFound();
            }

            return View(uebung);
        }

        // GET: Uebungs/Create
        public IActionResult Create()
        {
            ViewData["MuskelgruppeID"] = new SelectList(_context.Muskelgruppen, "MuskelgruppeID", "Bezeichnung");

            return View();
        }

        // POST: Uebungs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UebungID,Bezeichnung,MuskelgruppeID")] Uebung uebung)

        {
            if (ModelState.IsValid)
            {
                _context.Add(uebung);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MuskelgruppeID"] = new SelectList(_context.Muskelgruppen, "MuskelgruppeID", "Bezeichnung", uebung.MuskelgruppeID);

            return View(uebung);
        }

        // GET: Uebungs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uebung = await _context.Uebungen.SingleOrDefaultAsync(m => m.UebungID == id);
            if (uebung == null)
            {
                return NotFound();
            }
            ViewData["MuskelgruppeID"] = new SelectList(_context.Muskelgruppen, "MuskelgruppeID", "MuskelgruppeID", uebung.MuskelgruppeID);
            return View(uebung);
        }

        // POST: Uebungs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("UebungID,Bezeichnung,MuskelgruppeID")] Uebung uebung)
        {
            if (id != uebung.UebungID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(uebung);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UebungExists(uebung.UebungID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MuskelgruppeID"] = new SelectList(_context.Muskelgruppen, "MuskelgruppeID", "MuskelgruppeID", uebung.MuskelgruppeID);
            return View(uebung);
        }

        // GET: Uebungs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uebung = await _context.Uebungen
                .Include(u => u.Muskelgruppe)
                .SingleOrDefaultAsync(m => m.UebungID == id);
            if (uebung == null)
            {
                return NotFound();
            }

            return View(uebung);
        }

        // POST: Uebungs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var uebung = await _context.Uebungen.SingleOrDefaultAsync(m => m.UebungID == id);
            _context.Uebungen.Remove(uebung);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool UebungExists(int id)
        {
            return _context.Uebungen.Any(e => e.UebungID == id);
        }
    }
}
