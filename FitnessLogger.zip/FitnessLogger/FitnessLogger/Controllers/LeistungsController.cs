﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FitnessLogger.Data;
using FitnessLogger.Models;
using NToastNotify;

namespace FitnessLogger.Controllers
{
    public class LeistungsController : Controller
    {
        private readonly Kontext _context;
        private readonly IToastNotification _toastNotification;

        public LeistungsController(Kontext context, IToastNotification toastNotification)
        {
            _context = context;
            _toastNotification = toastNotification;
        }

        // GET: Leistungs
        public async Task<IActionResult> Index(string sortOrder, string searchString)
        {

            // Leistungsdaten inklusive Nutzer und Übungen laden
            var kontext = _context.Leistungen.Include(l => l.Nutzer).Include(l => l.Uebung);

            // Sortierung vornehmen
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewBag.DatumSortParm = sortOrder == "Datum" ? "datum_desc" : "Datum";
            ViewBag.UebungSortParm = sortOrder == "Uebung" ? "uebung_desc" : "Uebung";
            ViewBag.GewichtSortParm = sortOrder == "Gewicht" ? "gewicht_desc" : "Gewicht";
            ViewBag.SatzSortParm = sortOrder == "Satz" ? "satz_desc" : "Satz";
            ViewBag.WiederholungenSortParm = sortOrder == "Wiederholungen" ? "wiederholungen_desc" : "Wiederholungen";


            var searchLeistungen = from s in kontext select s;

            // Suchenfunktion
            if (!String.IsNullOrEmpty(searchString))
            {
                searchLeistungen = searchLeistungen.Where(s => s.Uebung.Bezeichnung.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    searchLeistungen = searchLeistungen.OrderByDescending(s => s.Nutzer);
                    break;
                case "Datum":
                    searchLeistungen = searchLeistungen.OrderBy(s => s.Datum);
                    break;
                case "datum_desc":
                    searchLeistungen = searchLeistungen.OrderByDescending(s => s.Datum);
                    break;
                case "Uebung":
                    searchLeistungen = searchLeistungen.OrderBy(s => s.Uebung.Bezeichnung);
                    break;
                case "uebung_desc":
                    searchLeistungen = searchLeistungen.OrderByDescending(s => s.Uebung.Bezeichnung);
                    break;
                case "Gewicht":
                    searchLeistungen = searchLeistungen.OrderBy(s => s.Gewicht);
                    break;
                case "gewicht_desc":
                    searchLeistungen = searchLeistungen.OrderByDescending(s => s.Gewicht);
                    break;
                case "Satz":
                    searchLeistungen = searchLeistungen.OrderBy(s => s.Satz);
                    break;
                case "satz_desc":
                    searchLeistungen = searchLeistungen.OrderByDescending(s => s.Satz);
                    break;
                case "Wiederholungen":
                    searchLeistungen = searchLeistungen.OrderBy(s => s.Wiederholungen);
                    break;
                case "wiederholungen_desc":
                    searchLeistungen = searchLeistungen.OrderByDescending(s => s.Wiederholungen);
                    break;
                default:
                    searchLeistungen = searchLeistungen.OrderByDescending(s => s.Datum);
                    break;
            }
                        
            // geänderten View zurückgeben
            return View(await searchLeistungen.ToListAsync());
        }
                
        // GET: Leistungs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var leistung = await _context.Leistungen
                .Include(l => l.Nutzer)
                .Include(l => l.Uebung)
                .SingleOrDefaultAsync(m => m.LeistungID == id);
            if (leistung == null)
            {
                return NotFound();
            }

            return View(leistung);
        }

        // GET: Leistungs/Create
        public IActionResult Create()
        {
            ViewData["NutzerID"] = new SelectList(_context.Nutzer, "NutzerID", "Benutzername");
            ViewData["UebungID"] = new SelectList(_context.Uebungen, "UebungID", "Bezeichnung");
            return View();
        }

        // POST: Leistungs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("LeistungID,Datum,Gewicht,Satz,Wiederholungen,UebungID,NutzerID")] Leistung leistung)
        {
            if (ModelState.IsValid)
            {
                _context.Add(leistung);
                await _context.SaveChangesAsync();

                // !!!!!!!!!!!!!!!!
                _toastNotification.AddToastMessage("bla", "bla", ToastEnums.ToastType.Success, new ToastOption()
                {
                    PositionClass = ToastPositions.TopCenter
                });

                return RedirectToAction(nameof(Index));
            }
            ViewData["NutzerID"] = new SelectList(_context.Nutzer, "NutzerID", "Benutzername", leistung.NutzerID);
            ViewData["UebungID"] = new SelectList(_context.Uebungen, "UebungID", "Bezeichnung", leistung.UebungID);
            return View(leistung);
        }

        // GET: Leistungs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var leistung = await _context.Leistungen.SingleOrDefaultAsync(m => m.LeistungID == id);
            if (leistung == null)
            {
                return NotFound();
            }
            ViewData["NutzerID"] = new SelectList(_context.Nutzer, "NutzerID", "Benutzername", leistung.NutzerID);
            ViewData["UebungID"] = new SelectList(_context.Uebungen, "UebungID", "Bezeichnung", leistung.UebungID);
            return View(leistung);
        }

        // POST: Leistungs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("LeistungID,Datum,Gewicht,Satz,Wiederholungen,UebungID,NutzerID")] Leistung leistung)
        {
            if (id != leistung.LeistungID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(leistung);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LeistungExists(leistung.LeistungID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["NutzerID"] = new SelectList(_context.Nutzer, "NutzerID", "Benutzername", leistung.NutzerID);
            ViewData["UebungID"] = new SelectList(_context.Uebungen, "UebungID", "Bezeichnung", leistung.UebungID);
            return View(leistung);
        }

        // GET: Leistungs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var leistung = await _context.Leistungen
                .Include(l => l.Nutzer)
                .Include(l => l.Uebung)
                .SingleOrDefaultAsync(m => m.LeistungID == id);
            if (leistung == null)
            {
                return NotFound();
            }

            return View(leistung);
        }

        // POST: Leistungs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var leistung = await _context.Leistungen.SingleOrDefaultAsync(m => m.LeistungID == id);
            _context.Leistungen.Remove(leistung);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LeistungExists(int id)
        {
            return _context.Leistungen.Any(e => e.LeistungID == id);
        }
    }
}
