﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FitnessLogger.Data;
using FitnessLogger.Models;

namespace FitnessLogger.Controllers
{
    public class MuskelgruppesController : Controller
    {
        private readonly Kontext _context;

        public MuskelgruppesController(Kontext context)
        {
            _context = context;
        }

        // GET: Muskelgruppes
        public async Task<IActionResult> Index(string sortOrder)
        {
            var kontext = _context.Muskelgruppen;

            ViewBag.MuskelSortParm = sortOrder == "Bezeichnung" ? "Muskel_desc" : "Bezeichnung";

            var orderedMuskelgruppe = from s in kontext select s;

            switch (sortOrder)
            {
                case "Bezeichnung":
                    orderedMuskelgruppe = orderedMuskelgruppe.OrderBy(s => s.Bezeichnung);
                        //_context.Muskelgruppen.OrderBy(s => s.Bezeichnung);
                    break;
                case "Muskel_desc":
                    orderedMuskelgruppe = orderedMuskelgruppe.OrderByDescending(s => s.Bezeichnung);
                    //_context.Muskelgruppen.OrderByDescending(s => s.Bezeichnung);
                    break;
                default:
                    orderedMuskelgruppe = orderedMuskelgruppe.OrderBy(s => s.Bezeichnung);
                    //_context.Muskelgruppen.OrderBy(s => s.Bezeichnung);
                    break;
            }

            //return View(await _context.Muskelgruppen.ToListAsync());
            return View(await orderedMuskelgruppe.ToListAsync());
        }

        // GET: Muskelgruppes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var muskelgruppe = await _context.Muskelgruppen
                .SingleOrDefaultAsync(m => m.MuskelgruppeID == id);
            if (muskelgruppe == null)
            {
                return NotFound();
            }

            return View(muskelgruppe);
        }

        // GET: Muskelgruppes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Muskelgruppes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MuskelgruppeID,Bezeichnung")] Muskelgruppe muskelgruppe)
        {
            if (ModelState.IsValid)
            {
                _context.Add(muskelgruppe);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(muskelgruppe);
        }

        // GET: Muskelgruppes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var muskelgruppe = await _context.Muskelgruppen.SingleOrDefaultAsync(m => m.MuskelgruppeID == id);
            if (muskelgruppe == null)
            {
                return NotFound();
            }
            return View(muskelgruppe);
        }

        // POST: Muskelgruppes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("MuskelgruppeID,Bezeichnung")] Muskelgruppe muskelgruppe)
        {
            if (id != muskelgruppe.MuskelgruppeID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(muskelgruppe);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MuskelgruppeExists(muskelgruppe.MuskelgruppeID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(muskelgruppe);
        }

        // GET: Muskelgruppes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var muskelgruppe = await _context.Muskelgruppen
                .SingleOrDefaultAsync(m => m.MuskelgruppeID == id);
            if (muskelgruppe == null)
            {
                return NotFound();
            }

            return View(muskelgruppe);
        }

        // POST: Muskelgruppes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var muskelgruppe = await _context.Muskelgruppen.SingleOrDefaultAsync(m => m.MuskelgruppeID == id);
            _context.Muskelgruppen.Remove(muskelgruppe);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MuskelgruppeExists(int id)
        {
            return _context.Muskelgruppen.Any(e => e.MuskelgruppeID == id);
        }
    }
}
