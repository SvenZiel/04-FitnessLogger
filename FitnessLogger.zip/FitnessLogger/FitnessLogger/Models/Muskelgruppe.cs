﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FitnessLogger.Models
{
    public class Muskelgruppe
    {
        public int MuskelgruppeID { get; set; }
        public string Bezeichnung { get; set; }
        
        public ICollection<Uebung> Uebungen { get; set; }
    }
}
