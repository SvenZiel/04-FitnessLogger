﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FitnessLogger.Models
{
    public class Leistung
    {
        public int LeistungID { get; set; }
        public DateTime Datum { get; set; }
        public int Gewicht { get; set; }
        public int Satz { get; set; }
        public int Wiederholungen { get; set; }

        public int UebungID { get; set; }
        public int NutzerID { get; set; }

        public Nutzer Nutzer { get; set; }
        public Uebung Uebung { get; set; }

        
    }
}
