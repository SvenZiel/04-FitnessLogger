﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace FitnessLogger.Models
{
    [DisplayName("Übung")]
    public class Uebung
    {
        [DisplayName("ÜbungID")]
        public int UebungID { get; set; }
        public string Bezeichnung { get; set; }

        public int MuskelgruppeID { get; set; }

        public Muskelgruppe Muskelgruppe { get; set; }
        public ICollection<Leistung> Leistungen { get; set; }
    }
}
