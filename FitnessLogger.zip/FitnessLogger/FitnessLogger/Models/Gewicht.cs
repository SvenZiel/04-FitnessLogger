﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace FitnessLogger.Models
{
    public class Gewicht
    {
        public int GewichtID { get; set; }
        public DateTime Datum { get; set; }

        [DisplayName("Körpergewicht")]
        public double Gewichte { get; set; }

        public int NutzerID { get; set; }

        public Nutzer Nutzer { get; set; }
    }
}
