﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FitnessLogger.Models
{
    public class Nutzer
    {
        public int NutzerID { get; set; }
        public string Name { get; set; }
        public string Vorname { get; set; }
        public string Benutzername { get; set; }
        public DateTime Geburtsdatum { get; set; }
        public string Passwort { get; set; }

        public ICollection<Leistung> Leistungen { get; set; }
        public ICollection<Gewicht> Gewichte { get; set; }

     
    }
}
