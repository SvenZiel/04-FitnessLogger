﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FitnessLogger.Models;

namespace FitnessLogger.Data
{
    public static class DbInitializer
    {
        public static void Initialize(Kontext kontext)
        {
            kontext.Database.EnsureCreated();

            if (kontext.Nutzer.Any())
            {
                return;
            }

            //Hier entstehen die Nutzerdaten
            var nutzer = new Nutzer[]
            {
                //new Nutzer{NutzerID=1,Benutzername="Trallafitti",Geburtsdatum=DateTime.Parse("2000-01-01"),Name="Stapper",Passwort="Test",Vorname="Andre"}

                new Nutzer{NutzerID=1,Name="Stapper",Vorname="Andre",Benutzername="Trallafitti09",Geburtsdatum=DateTime.Parse("2000-01-01"),Passwort="Test"},
                new Nutzer{NutzerID=2,Name="Schörner",Vorname="Yannick",Benutzername="Lolipopgammler",Geburtsdatum=DateTime.Parse("2000-02-02"),Passwort="Test"},
                new Nutzer{NutzerID=3,Name="Zielonka",Vorname="Sven",Benutzername="Shynara",Geburtsdatum=DateTime.Parse("1950-02-02"),Passwort="Test"},
                new Nutzer{NutzerID=4,Name="Braun",Vorname="Jens",Benutzername="PSfalke",Geburtsdatum=DateTime.Parse("1996-03-06"),Passwort="Test"},
                new Nutzer{NutzerID=5,Name="Admin",Vorname="Admin",Benutzername="Admin",Geburtsdatum=DateTime.Parse("2000-10-10"),Passwort="Admin"}
            };

            foreach(Nutzer n in nutzer)
            {
                kontext.Nutzer.Add(n);
            }
            kontext.SaveChanges();

            //Hier entstehen Muskelgruppen
            //var muskelgruppen = new Muskelgruppe[]
            //{
            //    new Muskelgruppe{MuskelgruppeID=1,Bezeichnung=Bezeichnung.Brust},
            //    new Muskelgruppe{MuskelgruppeID=2,Bezeichnung=Bezeichnung.Beine},
            //    new Muskelgruppe{MuskelgruppeID=3,Bezeichnung=Bezeichnung.Bizeps},
            //    new Muskelgruppe{MuskelgruppeID=4,Bezeichnung=Bezeichnung.Bauch},
            //    new Muskelgruppe{MuskelgruppeID=5,Bezeichnung=Bezeichnung.Rücken},
            //    new Muskelgruppe{MuskelgruppeID=6,Bezeichnung=Bezeichnung.Schultern},
            //    new Muskelgruppe{MuskelgruppeID=7,Bezeichnung=Bezeichnung.Trizeps},
            //    new Muskelgruppe{MuskelgruppeID=8,Bezeichnung=Bezeichnung.Waden}
            //};

            //foreach(Muskelgruppe m in muskelgruppen)
            //{
            //    kontext.Muskelgruppen.Add(m);
            //}
            //kontext.SaveChanges();

            //Hier entstehen die Übungen
            var uebungen = new Uebung[]
            {
                new Uebung{UebungID=1,Bezeichnung="Bankdrücken",MuskelgruppeID=1},
                new Uebung{UebungID=2,Bezeichnung="Fliegende",MuskelgruppeID=1},
                new Uebung{UebungID=3,Bezeichnung="Sit Ups",MuskelgruppeID=4},
                new Uebung{UebungID=4,Bezeichnung="Bauchpresse",MuskelgruppeID=4},
                new Uebung{UebungID=5,Bezeichnung="Kniebeugen",MuskelgruppeID=2},
                new Uebung{UebungID=6,Bezeichnung="Beinpresse",MuskelgruppeID=2},
                new Uebung{UebungID=7,Bezeichnung="Langhantelcurls",MuskelgruppeID=3},
                new Uebung{UebungID=8,Bezeichnung="Hammercurls",MuskelgruppeID=3},
                new Uebung{UebungID=9,Bezeichnung="Klimmzüge",MuskelgruppeID=5},
                new Uebung{UebungID=10,Bezeichnung="Langhantelrudern",MuskelgruppeID=5},
                new Uebung{UebungID=11,Bezeichnung="Schulterdrücken",MuskelgruppeID=6},
                new Uebung{UebungID=12,Bezeichnung="Seitheben",MuskelgruppeID=6},
                new Uebung{UebungID=13,Bezeichnung="Dips",MuskelgruppeID=7},
                new Uebung{UebungID=14,Bezeichnung="Frenchpress",MuskelgruppeID=7},
                new Uebung{UebungID=15,Bezeichnung="Wadenheben",MuskelgruppeID=8},
                new Uebung{UebungID=16,Bezeichnung="Wadenpresse",MuskelgruppeID=8}
            };

            foreach(Uebung u in uebungen)
            {
                kontext.Uebungen.Add(u);
            }
            kontext.SaveChanges();

            //Hier entstehen die Leistungstestdaten
            var leistungen = new Leistung[]
            {
                new Leistung{LeistungID=1,Datum=DateTime.Parse("2017-12-12"),Gewicht=100,Satz=1,Wiederholungen=10,UebungID=1,NutzerID=1},
                new Leistung{LeistungID=2,Datum=DateTime.Parse("2017-12-12"),Gewicht=100,Satz=2,Wiederholungen=8,UebungID=1,NutzerID=1},
                new Leistung{LeistungID=3,Datum=DateTime.Parse("2017-12-12"),Gewicht=100,Satz=3,Wiederholungen=12,UebungID=1,NutzerID=1},
                new Leistung{LeistungID=4,Datum=DateTime.Parse("2017-12-12"),Gewicht=30,Satz=1,Wiederholungen=12,UebungID=2,NutzerID=1},
                new Leistung{LeistungID=5,Datum=DateTime.Parse("2017-12-12"),Gewicht=35,Satz=2,Wiederholungen=10,UebungID=2,NutzerID=1},

                new Leistung{LeistungID=6,Datum=DateTime.Parse("2017-12-12"),Gewicht=0,Satz=1,Wiederholungen=10,UebungID=3,NutzerID=2},
                new Leistung{LeistungID=7,Datum=DateTime.Parse("2017-12-12"),Gewicht=0,Satz=2,Wiederholungen=10,UebungID=3,NutzerID=2},
                new Leistung{LeistungID=8,Datum=DateTime.Parse("2017-12-12"),Gewicht=0,Satz=3,Wiederholungen=10,UebungID=3,NutzerID=2},
                new Leistung{LeistungID=9,Datum=DateTime.Parse("2017-12-12"),Gewicht=10,Satz=1,Wiederholungen=10,UebungID=4,NutzerID=2},
                new Leistung{LeistungID=10,Datum=DateTime.Parse("2017-12-12"),Gewicht=10,Satz=2,Wiederholungen=10,UebungID=4,NutzerID=2},

                new Leistung{LeistungID=11,Datum=DateTime.Parse("2017-12-12"),Gewicht=40,Satz=1,Wiederholungen=12,UebungID=15,NutzerID=3},
                new Leistung{LeistungID=12,Datum=DateTime.Parse("2017-12-12"),Gewicht=40,Satz=2,Wiederholungen=12,UebungID=15,NutzerID=3},
                new Leistung{LeistungID=13,Datum=DateTime.Parse("2017-12-12"),Gewicht=60,Satz=1,Wiederholungen=10,UebungID=16,NutzerID=3},
                new Leistung{LeistungID=14,Datum=DateTime.Parse("2017-12-12"),Gewicht=60,Satz=2,Wiederholungen=10,UebungID=16,NutzerID=3},
                new Leistung{LeistungID=15,Datum=DateTime.Parse("2017-12-12"),Gewicht=60,Satz=3,Wiederholungen=10,UebungID=16,NutzerID=3},

                new Leistung{LeistungID=16,Datum=DateTime.Parse("2017-12-12"),Gewicht=150,Satz=1,Wiederholungen=8,UebungID=5,NutzerID=4},
                new Leistung{LeistungID=17,Datum=DateTime.Parse("2017-12-12"),Gewicht=150,Satz=2,Wiederholungen=8,UebungID=5,NutzerID=4},
                new Leistung{LeistungID=18,Datum=DateTime.Parse("2017-12-12"),Gewicht=150,Satz=3,Wiederholungen=8,UebungID=5,NutzerID=4},
                new Leistung{LeistungID=19,Datum=DateTime.Parse("2017-12-12"),Gewicht=400,Satz=1,Wiederholungen=10,UebungID=6,NutzerID=4},
                new Leistung{LeistungID=20,Datum=DateTime.Parse("2017-12-12"),Gewicht=400,Satz=2,Wiederholungen=10,UebungID=6,NutzerID=4},

                new Leistung{LeistungID=21,Datum=DateTime.Parse("2017-12-12"),Gewicht=800,Satz=1,Wiederholungen=8,UebungID=13,NutzerID=5},
                new Leistung{LeistungID=22,Datum=DateTime.Parse("2017-12-12"),Gewicht=800,Satz=2,Wiederholungen=8,UebungID=13,NutzerID=5},
                new Leistung{LeistungID=23,Datum=DateTime.Parse("2017-12-12"),Gewicht=800,Satz=3,Wiederholungen=8,UebungID=13,NutzerID=5},
                new Leistung{LeistungID=24,Datum=DateTime.Parse("2017-12-12"),Gewicht=800,Satz=4,Wiederholungen=8,UebungID=13,NutzerID=5},
                new Leistung{LeistungID=25,Datum=DateTime.Parse("2017-12-12"),Gewicht=800,Satz=5,Wiederholungen=8,UebungID=13,NutzerID=5}
            };

            foreach(Leistung l in leistungen)
            {
                kontext.Leistungen.Add(l);
            }
            kontext.SaveChanges();

        }
    }
}
