﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FitnessLogger.Models;
using Microsoft.EntityFrameworkCore;
using FitnessLogger.Data;


namespace FitnessLogger.Data
{
    public class Kontext : DbContext
    {
        public Kontext(DbContextOptions<Kontext> options) : base(options)
        {

        }

        public DbSet<Leistung> Leistungen { get; set;} 
        public DbSet<Muskelgruppe> Muskelgruppen { get; set; }
        public DbSet<Nutzer> Nutzer { get; set; }
        public DbSet<Uebung> Uebungen { get; set; }
        public DbSet<ApplicationUser> ApplicationUser { get; set; }
        public DbSet<Gewicht> Gewichte { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Leistung>().ToTable("Leistung");
            modelBuilder.Entity<Muskelgruppe>().ToTable("Muskelgruppe");
            modelBuilder.Entity<Nutzer>().ToTable("Nutzer");
            modelBuilder.Entity<Uebung>().ToTable("Uebung");
            modelBuilder.Entity<ApplicationUser>().ToTable("ApplicationUser");
            modelBuilder.Entity<Gewicht>().ToTable("Gewicht");
        }

    }
}
